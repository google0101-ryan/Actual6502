#include "Memory.hpp"
#include <iostream>
#include <fstream>
#include <sstream>

using std::runtime_error;

typedef uint8_t (*BusRead)(uint16_t);
BusRead Read;

byte mem::Read(word Address)
{
    return ram[Address];
}

void mem::Write(word Address, byte value)
{
    ram[Address] = value;
}

void mem::readFile(const vector<uint8_t>& program)
{
	uint16_t code_size = program.size();
    uint32_t code_end = 0 + code_size;
    if (code_end > 1024*64)
    {
        throw runtime_error("Prog does not fit in mem");
    }

    for (auto i = 0; i < program.size(); i++)
    {
        Write(i, program[i]);
    }
}