#include "Memory.hpp"
#include "CPU.hpp"
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>

using namespace std;

int main()
{
    mem* ram = new mem();

    for (uint64_t i = 0; i < 1024*64; i++)
    {
        ram->Write(i, 0xEA);
    }
    ram->Write(0x7FFC, 0x42);
    ram->Write(0x7FFD, 0x42);
    ram->Write(0x4242, 0xa2);
    ram->Write(0x4243, 0x84);
    ram->Write(0x4244, 0x9a);
    ram->Write(0x4245, 0x00);
#if 0
   string hex = "a.out";

    ifstream in(hex, ios_base::binary);
    if (in.fail())
        throw runtime_error("Failed to read program file");

    vector<uint8_t> code(
            (istreambuf_iterator<char>(in)),
            (istreambuf_iterator<char>()));

    ram->readFile(code);


    for (uint64_t i = 0; i < 1024*64; i++)
    {
        printf("Mem Address %d: 0x%x\n", i, ram->Read(i));
    }
#endif

    CPU* cpu = new CPU(ram);

    printf("PC: 0x%x\n", cpu->PC);

    cout << "RAM Inited\n";

    cpu->Run();

    cpu->DumpRegs();

    return 0;
}