#include "CPU.hpp"
#include <cstdio>

CPU::CPU(mem* mem)
{
    ram = mem;
    PC = ((uint16_t)(ram->Read(0x7ffc)) << 8) | (ram->Read(0x7ffd));
    SP = 0xff;
};

uint8_t CPU::Fetch()
{
    uint8_t val = ram->Read(PC);
    return val;
}

void CPU::Decode(uint8_t opcode)
{
    switch(opcode)
    {
        case 0xEA:
            PC++;
            break;
        case 0xA9:
            A = ram->Read(++PC);
            PC++;
            break;
        case 0x8d:
        {
            uint8_t place1 = ram->Read(++PC);
            uint8_t place2 = ram->Read(++PC);
            uint16_t storePlace = (place2 << 8) | place1;
            ram->Write(storePlace, A);
            printf("Value at 0x%x should be 0x%x\n", storePlace, A);
            printf("Actual value: 0x%x\n", ram->Read(storePlace));
            PC++;
            break;
        }
        case 0x4c:
        {
            if (!jmpTimes) {
                uint8_t place1 = ram->Read(++PC);
                uint8_t place2 = ram->Read(++PC);
                uint16_t jmpAddr = (place2 << 8) | place1;
                printf("JmpAddr: 0x%x\n", jmpAddr);
                PC = jmpAddr;
                jmpTimes++;
                printf("%d\n", jmpTimes);
            } else {
                PC++;
            }
        }
            break;
        case 0x6a:
        {
            unsigned char tmp8 = 0;

            tmp8 = A;
            A = A >> 1;

            if (CheckFlag(C))
            {
                A |= 0x80;
            } else {
                A &= 0x7F;
            }

            SetFlag(((A & 0x01) == 0x01), C);
            SetFlags(A);
        }
            break;
        case 0xa2:
        {
            X = ram->Read(++PC);
            PC++;
        } break;
        case 0x9a:
        {
            ram->Write(SP, X);
            printf("Value at 0x%x should be 0x%x\n", SP, X);
            printf("Actual value: 0x%x\n", ram->Read(SP));
            if (SP == 0x0)
            {
                SP = 0xff;
            } else {
                SP--;
            }
            PC++;
        } break;
        case 0:
            halt = true;
            break;
        default:
            PC++;
            break;
    }
    //printf("PC: 0x%x\n", PC);
}

void CPU::Run()
{
    while (!halt)
    {
        Decode(Fetch());
    }
}

void CPU::DumpRegs()
{
    printf("A: 0x%x\n", A);
    printf("X: 0x%x\n", X);
    printf("Y: 0x%x\n", Y);
    printf("C: %d\n", C);
    printf("PC: 0x%x\n", PC);
    printf("SP: 0x%x\n", SP);
}


bool CPU::CheckFlag(unsigned char flag)
{
    return ((C & flag) == flag);
}

void CPU::SetFlag(bool set, unsigned char flag)
{
    if (set)
    {
        C |= flag;
    } else {
        C &= ~flag;
    }
}

void CPU::SetFlags(unsigned char reg)
{
    SetFlag((0 == reg), Z);
    SetFlag(((reg & 0x80) == 0x80), 0x80);
    SetFlag(true, 0x20);
}