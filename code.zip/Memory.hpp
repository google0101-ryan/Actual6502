#pragma once

#include <cstdint>
#include <vector>

typedef uint8_t byte;
typedef uint32_t word;

using std::vector;

class mem
{
private:
    byte ram[1024*64];
public:
    uint8_t Read(word Address);
    void Write(word Address, byte Value);
    void readFile(const vector<uint8_t>& program);
};