#pragma once

#include "Memory.hpp"

class CPU
{
private:
    byte A, X, Y, SP;
    byte C : 1, Z, I, D, V, N;
    int jmpTimes = 0;
    mem* ram;
    bool halt = false;
public:
    CPU(mem* mem);
    uint16_t PC;
    uint8_t Fetch();
    void Decode(uint8_t opcode);
    void Run();
    void DumpRegs();
    bool CheckFlag(unsigned char flag);
    void SetFlag(bool set, unsigned char flag);
    void SetFlags(unsigned char regs);
};